This lab will teach about the commands to pull and run docker containers.
You will write the commands in the file in src/main/resources/Lab.txt.
The tests that will verify your commands are written in src/test/DockerTest.
The tests are written in Java using JUnit. An understanding of Java / JUnit is not needed in order to complete this lab.
